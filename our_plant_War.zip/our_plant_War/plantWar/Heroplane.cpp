#include "heroplane.h"
#include "config.h"
#include <iostream>
/*
HeroPlane::HeroPlane()
{
    m_plane.load(HERO_PICTURE);

    //坐标初始化
    m_x=(GAME_WIDTH-m_plane.width())/2;
    m_y=GAME_HEIGHT-m_plane.width();

    //初始化边框
    m_rect.setWidth(m_plane.width());
    m_rect.setHeight(m_plane.height());
    m_rect.moveTo(m_x,m_y);

    //初始化子弹
    m_record=0;
}


void HeroPlane::shoot()
{
    m_record++;
    if(m_record>=HERO_SHOOT_INTERVAL)
        m_record=0;
    else return;

    int i;
    for (i=0;;i++)
    {
        if(i==HERO_BULLET_NUM)
        {
            std::cerr<<"英雄子弹数量不足"<<std::endl;
            break;
        }
        if(m_bul[i].m_free)
        {
            m_bul[i].m_free=false;
            m_bul[i].m_x=m_x+m_rect.width()/2-m_bul[i].m_rect.width()/2;
            m_bul[i].m_y=m_y;
            break;
        }
    }

}

void HeroPlane::setPosition(int x, int y)
{
    m_x=x;
    m_y=y;
    m_rect.moveTo(x,y);

}

EnermyPlane::EnermyPlane():HeroPlane ()
{
    m_plane.load(ENERMY_PICTURE);
    //坐标初始化
    m_x=(GAME_WIDTH-m_plane.width())/2;
    m_y=GAME_HEIGHT-m_plane.width();

    //初始化边框
    m_rect.setWidth(m_plane.width());
    m_rect.setHeight(m_plane.height());
    m_rect.moveTo(m_x,m_y);

    //初始化子弹
    m_record=0;

    //初始化状态
    m_free=false;
    m_rate=ENERMY_MOVE_RATE;
    m_life=ENERMY_LIFE;
}

void EnermyPlane::setPosition(int x,int y)
{
    if(m_free)
        return;
    m_y+=m_rate;
    m_rect.moveTo(m_x,m_y);

    if(m_y>=GAME_HEIGHT+10)
        m_free=true;
}
*/
