#include "MBullet.h"
#include "MPlant.h"
#include "config.h"
#include <QDebug>
#include "boss.h"

//extern Boss boss;
HeroBullet::HeroBullet()
{
    //子弹图片
    m_bullet.load(HERO_BULLET_PICTURE);
    //坐标
    m_x=300;
    m_y=300;
    //判定
    m_rect.setWidth(m_bullet.width());
    m_rect.setHeight(m_bullet.height());
    m_rect.moveTo(m_x,m_y);
    //速度
    m_speed=HERO_BULLET_SPEED;
    //伤害
    m_power=HERO_BULLET_POWER;
    //类型
    sort=HERO_SORT_SIGN;
    //闲置
    m_free=true;
}

void HeroBullet::updatePosition()
{
    if(m_free==true)
    {
        return;
    }
    else
    {
        m_y-=m_speed;
        m_rect.moveTo(m_x,m_y);
    }
    if(m_y<=0-50)//减多少没关系，就是让它移出屏幕而已
        m_free=true;
}

void HeroBullet::collisionDetection()
{


    if(this->m_free)
        return;

    int i;
    for(i=0;i<100;i++)
    {
        if(!Registerplane[i])
        {
            break;
        }
        if(Registerplane[i]->m_free)
        {
            continue;
        }
        if(Registerplane[i]->m_rect.intersects(this->m_rect))
        {
            this->m_free=true;
            this->initBullet();
            Registerplane[i]->m_life -= this->m_power;
            if(Registerplane[i]->m_life<=0)
            {
                Registerplane[i]->m_free=true;
                Registerplane[i]->m_bombs.m_x = Registerplane[i]->m_x;
                Registerplane[i]->m_bombs.m_y = Registerplane[i]->m_y;
                Registerplane[i]->m_bombs.bombfree = false;
                Registerplane[i]->initBullet();
                gameScore+=3;


            }
            break;
        }
    }

    if(BOSSPLANE->free==false)
    {
        qDebug()<<"dfdfdf";
        this->collisionDetectionboss();
    }

}

void HeroBullet::collisionDetectionboss()
{
    if(BOSSPLANE->free==1)
    {
        return;
    }
    else
    {
        if(BOSSPLANE->rect.intersects(this->m_rect))
        {
           qDebug()<<"bosslife"<<BOSSPLANE->health;
            BOSSPLANE->health-=this->m_power;
            this->m_free=true;
            this->initBullet();

            if(BOSSPLANE->health<=0)
            {
                BOSSPLANE->free=true;
                BOSSPLANE->m_bombs.m_x = BOSSPLANE->m_x;
                BOSSPLANE->m_bombs.m_y = BOSSPLANE->m_y;
                BOSSPLANE->m_bombs.bombfree = false;
                gameScore+=100;
            }

        }
    }
}


void HeroBullet::initBullet()
{
    m_x=300;
    m_y=300;
    m_rect.moveTo(m_x,m_y);
    m_free=true;
}

HeroBullet2::HeroBullet2()
{
    //子弹图片
    m_bullet.load(HERO_BULLET_PICTURE2);
    //坐标
    m_x=300;
    m_y=300;
    //判定
    m_rect.setWidth(m_bullet.width());
    m_rect.setHeight(m_bullet.height());
    m_rect.moveTo(m_x,m_y);
    //速度
    m_speed=HERO_BULLET_SPEED;
    //伤害
    m_power=HERO_BULLET_POWER+10;
    //类型
    sort=HERO_SORT_SIGN;
    //闲置
    m_free=true;
    //抛物率
    paowulv=-5;
}
void HeroBullet2::updatePosition()
{
    if(m_free==true)
    {
        return;
    }
    else
    {
        m_y-=m_speed;
        m_x+=paowulv*3;
        paowulv++;
        m_rect.moveTo(m_x,m_y);
    }
    if(m_y<=0-50&&m_x>300)//减多少没关系，就是让它移出屏幕而已
    { m_free=true;paowulv=-5;}
}

void HeroBullet2::initBullet()
{
    m_x=300;
    m_y=300;
    m_rect.moveTo(m_x,m_y);
    m_free=true;
    paowulv=-5;
}







EnermyBullet::EnermyBullet()
{
    //子弹图片
    m_bullet.load(BOSS_BULLET_PICTURE);
    //坐标
    m_x=300;
    m_y=300;
    //判定
    m_rect.setWidth(m_bullet.width());
    m_rect.setHeight(m_bullet.height());
    m_rect.moveTo(m_x,m_y);
    //速度
    m_speed=ENERMY2_BULLET_SPEED;
    //伤害
    m_power=ENERMY2_BULLET_POWER;
    //类型
    sort=ENERMY_SORT_SIGN;
    //闲置
    m_free=true;
}

void EnermyBullet::updatePosition()
{
    if(m_free==true)
    {
        return;
    }
    else
    {
        m_y+=m_speed;
        m_rect.moveTo(m_x,m_y);
    }
    if(m_y>=GAME_HEIGHT)//减多少没关系，就是让它移出屏幕而已
    {
        this->initBullet();
    }
}

void EnermyBullet::collisionDetection()
{
    if(this->m_free)
        return;

    if(Userplane->m_rect.intersects(this->m_rect))
    {
        this->m_free=true;
        this->initBullet();

        Userplane->m_life-=this->m_power;
        qDebug()<<"我方被敌人射击，这是测试撞击鉴定，当前血量："<<Userplane->m_life;
        if(Userplane->m_life<=0)
        {
            qDebug()<<"玩家应该已经游戏结束";
        }
    }
}


void EnermyBullet::initBullet()
{
    m_x=300;
    m_y=0;
    m_rect.moveTo(m_x,m_y);
    m_free=true;
}







BossBullet2::BossBullet2()
{
    //子弹图片
    m_bullet.load(BOSS_BULLET_PICTURE2);
    //坐标
    m_x=300;
    m_y=300;
    //判定
    m_rect.setWidth(m_bullet.width());
    m_rect.setHeight(m_bullet.height());
    m_rect.moveTo(m_x,m_y);
    //速度
    m_speed=BOSS_BULLET_SPEED;
    //伤害
    m_power=BOSS_BULLET_POWER;

    //闲置
    m_free=true;
}

void BossBullet2::updatePosition()
{
    if(m_free==true)
    {
        return;
    }
    else
    {
        m_y+=m_speed;
        m_rect.moveTo(m_x,m_y);
        this->collisionDetection();
    }
    if(m_y>=GAME_HEIGHT)//减多少没关系，就是让它移出屏幕而已
    {
        this->initBullet();
    }
}

void BossBullet2::collisionDetection()
{
   if(this->m_free)
        return;

    if(Userplane->m_rect.intersects(this->m_rect))
    {
        this->m_free=true;
        this->initBullet();

        Userplane->m_life-=this->m_power;
        qDebug()<<"我方被敌人射击，这是测试撞击鉴定，当前血量："<<Userplane->m_life;
        if(Userplane->m_life<=0)
        {
            qDebug()<<"玩家应该已经游戏结束";
        }
    }
}

void BossBullet2::initBullet()
{
    m_x=300;
    m_y=-300;
    m_rect.moveTo(m_x,m_y);
    m_free=true;
}

BossBullet1::BossBullet1()
{
    //子弹图片
    m_bullet.load(BOSS_BULLET_PICTURE);
    //坐标
    m_x=300;
    m_y=0;
    //判定
    m_rect.setWidth(m_bullet.width());
    m_rect.setHeight(m_bullet.height());
    m_rect.moveTo(m_x,m_y);
    //速度
    m_speed=BOSS_BULLET_SPEED;
    //伤害
    m_power=BOSS_BULLET_POWER;

    //闲置
    m_free=true;
}

void BossBullet1::updatePosition()
{
    if(m_free==true)
    {
        return;
    }
    else
    {
        m_y+=m_speed;
        m_rect.moveTo(m_x,m_y);
        this->collisionDetection();
    }
    if(m_y>=GAME_HEIGHT)//减多少没关系，就是让它移出屏幕而已
    {
        this->initBullet();
    }
}

void BossBullet1::collisionDetection()
{
    if(this->m_free)
         return;

     if(Userplane->m_rect.intersects(this->m_rect))
     {
         this->m_free=true;
         this->initBullet();

         Userplane->m_life-=this->m_power;
         qDebug()<<"我方被敌人射击，这是测试撞击鉴定，当前血量："<<Userplane->m_life;
         if(Userplane->m_life<=0)
         {
             qDebug()<<"玩家应该已经游戏结束";
         }
     }
}

void BossBullet1::initBullet()
{
    m_x=300;
    m_y=-300;
    m_rect.moveTo(m_x,m_y);
    m_free=true;
}
