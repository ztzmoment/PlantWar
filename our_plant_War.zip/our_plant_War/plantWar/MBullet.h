#ifndef MBULLET_H
#define MBULLET_H

#include "config.h"
#include <QPixmap>
#include "bomb.h"

class MBullet
{
public:
    //更新子弹坐标
    virtual void updatePosition()=0;
    //子弹碰撞检测
    virtual void collisionDetection()=0;
    //子弹初始化为被构造状态，其中m_free设为true
    virtual void initBullet()=0;
    virtual ~MBullet(){}
public:
    //图片
    QPixmap m_bullet;
    //坐标
    int m_x;
    int m_y;
    //判定
    QRect m_rect;
    //速度
    int m_speed;
    //伤害
    int m_power;
    //类型,标志着攻击对象
    int sort;
    //闲置
    bool m_free;
};



class HeroBullet: public MBullet
{
    friend class enmey;
public:

    HeroBullet();
    //更新坐标
    virtual void updatePosition();
    //
    virtual void collisionDetection();
    virtual void collisionDetectionboss();


    virtual void initBullet();
};

class HeroBullet2:public HeroBullet
{
public:
    HeroBullet2();
    virtual void updatePosition();
    virtual void initBullet();
private:
    //抛物率
    int paowulv;
};

class EnermyBullet: public MBullet
{
public:
    EnermyBullet();
    virtual void updatePosition();
    virtual void collisionDetection();
    virtual void initBullet();
};

class BossBullet1: public MBullet
{
public:
    BossBullet1();
    virtual void updatePosition();
    virtual void collisionDetection();
    virtual void initBullet();
};

class BossBullet2: public MBullet
{
public:
    BossBullet2();
    virtual void updatePosition();
    virtual void collisionDetection();
    virtual void initBullet();
};
#endif // MBULLET_H
