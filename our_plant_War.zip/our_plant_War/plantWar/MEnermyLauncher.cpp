#include "MEnermyLauncher.h"
#include <QtGlobal>
void LauncherEnermySet::shoot()
{
    m_record++;
    if(m_record<m_interval)
    {
        return;
    }
    m_record=0;

    int i;
    for (i=0;;i++)
    {
        if(i==m_num)
        {
            qDebug()<<"敌机数量不足";
            break;
        }
        if(m_bullet[i].m_free)
        {
            m_bullet[i].initBullet();

            m_bullet[i].m_x=qrand()%(GAME_WIDTH-m_bullet[i].m_plane.width());
            m_bullet[i].m_y=0-m_bullet[i].m_rect.height();
            m_bullet[i].m_free=false;
            break;
        }
    }
}

void LauncherEnermySet::collisionLauncherDetection()
{
    int i=0;
    for(i=0;i<m_num;i++)
    {
        if(m_bullet[i].m_free==true)
        {
            continue;
        }
        m_bullet[i].acting();
    }
}


void LauncherEnermy2Set::shoot()
{
    m_record++;
    if(m_record<m_interval)
    {
        return;
    }
    m_record=0;

    int i;
    for (i=0;;i++)
    {
        if(i==m_num)
        {
            qDebug()<<"敌机数量不足";
            break;
        }
        if(m_bullet[i].m_free)
        {
            m_bullet[i].initBullet();

            m_bullet[i].m_x=qrand()%(GAME_WIDTH-this->m_bullet[0].m_plane.width());
            m_bullet[i].m_y=0-m_bullet[i].m_rect.height();
            m_bullet[i].m_free=false;
            break;
        }
    }
}

void LauncherEnermy2Set::collisionLauncherDetection()
{
    int i=0;
    for(i=0;i<m_num;i++)
    {
        if(m_bullet[i].m_free==true)
        {
            continue;
        }
        m_bullet[i].acting();
    }
}


void LauncherEnermy3Set::shoot()
{
    m_record++;
    if(m_record<m_interval)
    {
        return;
    }
    m_record=0;

    int i;
    for (i=0;;i++)
    {
        if(i==m_num)
        {
            qDebug()<<"敌机数量不足";
            break;
        }
        if(m_bullet[i].m_free)
        {
            m_bullet[i].initBullet();
            m_bullet[i].m_x=qrand()%(GAME_WIDTH-this->m_bullet[0].m_plane.width());
            m_bullet[i].m_y=0-m_bullet[i].m_rect.height();
            m_bullet[i].m_free=false;
            break;
        }
    }
}

void LauncherEnermy3Set::collisionLauncherDetection()
{
    int i=0;
    for(i=0;i<m_num;i++)
    {
        if(m_bullet[i].m_free==true)
        {
            continue;
        }
        m_bullet[i].acting();
    }
}
