#ifndef MENERMYLAUNCHER_H
#define MENERMYLAUNCHER_H

#include "MLauncher.h"
#include "MPlant.h"


class LauncherEnermySet:public MLauncher<EnermyPlane,ENERMY_NUM,ENERMY_INTERVAL>
{
public:
    LauncherEnermySet():MLauncher<EnermyPlane,ENERMY_NUM,ENERMY_INTERVAL>(){}
    //重载shoot为发射敌机
    virtual void shoot();
    //重载collisionLauncherDetection为执行acting
    virtual void collisionLauncherDetection();

};

//敌机2的发射器
class LauncherEnermy2Set:public MLauncher<EnermyPlane2,ENERMY2_NUM,ENERMY2_INTERVAL>
{
public:
    LauncherEnermy2Set():MLauncher<EnermyPlane2,ENERMY2_NUM,ENERMY2_INTERVAL>(){}
    //重载shoot为发射敌机,代码和LauncherEnermySet的完全一样
    virtual void shoot();
    //重载collisionLauncherDetection为执行acting，代码和LauncherEnermySet的完全一样
    virtual void collisionLauncherDetection();

};

//敌机3的发射器
class LauncherEnermy3Set:public MLauncher<EnermyPlane3,ENERMY3_NUM,ENERMY3_INTERVAL>
{
public:
    LauncherEnermy3Set():MLauncher <EnermyPlane3,ENERMY3_NUM,ENERMY3_INTERVAL>(){}
    //重载shoot为发射敌机
    virtual void shoot();
    //重载collisionLauncherDetection为执行acting
    virtual void collisionLauncherDetection();
};


#endif // MENERMYLAUNCHER_H
