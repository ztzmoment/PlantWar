#ifndef MLAUNCHER_H
#define MLAUNCHER_H

#include <QPixmap>
#include "config.h"
#include "MBullet.h"
#include <QDebug>
class MPlane;

//抽象类，类似于弹夹的功能。
//负责1.提供子弹，2.发射子弹，3.调用全部子弹移动函数，4.调用该弹夹所有子弹的碰撞判定，5.在敌机毁灭后可消除其发出的子弹（非必要）
//T的概念：1.有bool：m_free参数，2.有collisionDetection()函数，3.有initBullet()函数，4.有updatePosition()函数
template<class T,int SIZE,int INTERVALL>
class MLauncher
{
public:
    MLauncher();
    //发射,传入该飞机（*this）
    virtual void shoot(MPlane &m_pl);
    //发射的无参重载
    virtual void shoot();
    //调用全部子弹移动
    virtual void updateLauncherPosition();
    //调用全部子弹攻击判定
    virtual void collisionLauncherDetection();
    //子弹全部失效
    virtual void freeLauncher();
public:
    //子弹数组
    T m_bullet[SIZE];
    //子弹数目
    int m_num;
    //发射间隔
    int m_interval;
    //现在间隔次数
    int m_record;
};



//模板类的定义和实现都要放到头文件中
template<class T, int SIZE,int INTERVAL>
MLauncher<T,SIZE,INTERVAL>::MLauncher()
{
    m_interval=INTERVAL;
    m_record=0;
    m_num=SIZE;
    int i;
    for(i=0;i<SIZE;i++)
    {
        m_bullet[i].initBullet();
    }
}

template<class T, int SIZE,int INTERVAL>
void MLauncher<T,SIZE,INTERVAL>::shoot()
{
    //一般是发射飞机，必然需要重载，这里略
}

template<class T, int SIZE, int INTERVAL>
void MLauncher<T,SIZE,INTERVAL>::updateLauncherPosition()
{
    int i=0;
    for(i=0;i<SIZE;i++)
    {
        if(m_bullet[i].m_free==true)
        {
            continue;
        }
        m_bullet[i].updatePosition();
    }
}

template<class T, int SIZE,int INTERVAL>
void MLauncher<T,SIZE,INTERVAL>::collisionLauncherDetection()
{
    int i=0;
    for(i=0;i<SIZE;i++)
    {
        if(m_bullet[i].m_free==true)
        {
            continue;
        }
        m_bullet[i].collisionDetection();
    }
}

template<class T, int SIZE,int INTERVAL>
void MLauncher<T,SIZE,INTERVAL>::freeLauncher()
{
    int i=0;
    for(i=0;i<SIZE;i++)
    {
        m_bullet[i].initBullet();
    }
}

#endif // LAUNCHER_H





#ifndef OTHERLAUNCHER
#define OTHERLAUNCHER
//见MPlant.h
//typedef MLauncher<HeroBullet,HERO_BULLET_NUM,HERO_BULLET_SPEED> HeroLancher;


#endif

