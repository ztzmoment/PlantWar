#include "MPlant.h"
#include "config.h"
//英雄初始化
HeroPlane::HeroPlane():m_launcher()
{
    //图片初始化
    m_plane.load(HERO_PICTURE);

    //坐标初始化
    m_x=(GAME_WIDTH-m_plane.width())/2;
    m_y=GAME_HEIGHT-m_plane.width();

    //初始化边框
    m_rect.setWidth(m_plane.width());
    m_rect.setHeight(m_plane.height());
    m_rect.moveTo(m_x,m_y);

    //初始化生命
    m_life=HERO_LIFE;
}
//英雄动作
void HeroPlane::acting()
{
    //每一回合
    //尝试一次子弹的发射
    m_launcher.shoot(*this);
    //进行一次全体子弹的攻击判定
    m_launcher.collisionLauncherDetection();
    //允许一次全体子弹移动
    m_launcher.updateLauncherPosition();
    //移动不放在act里
}
//英雄位置
void HeroPlane::setPosition(int x, int y)
{
    m_x=x;
    m_y=y;
    m_rect.moveTo(x,y);
}





//敌人初始化
EnermyPlane::EnermyPlane()
{
    //图片初始化
    m_plane.load(ENERMY_PICTURE);

    //坐标初始化
    m_x=(GAME_WIDTH-m_plane.width())/2;
    m_y=GAME_HEIGHT-m_plane.width();

    //初始化边框
    m_rect.setWidth(m_plane.width());
    m_rect.setHeight(m_plane.height());
    m_rect.moveTo(m_x,m_y);

    //初始化生命
    m_life=ENERMY_LIFE;
    //初始化速度
    m_speed=ENERMY_SPEED;

    //初始化伤害
    m_power=ENERMY_POWER;
    //初始化伤害间隔
    m_power_interval=ENERMY_POWER_INTERVAL;
    //初始化撞击次数
    m_power_record=0;

    //初始化闲置
    m_free=true;
}
//敌人动作
void EnermyPlane::acting()
{
    //每一回合
    //撞击攻击检测
    collisionDetection();
    //已将LauncherEnermySet::collisionLauncherDetection的collisionDetection()重载为执行acting。
}
//敌人移动
void EnermyPlane::setPosition(int, int)
{
    if(m_free==true)
    {
        return;
    }
    else
    {
        m_y+=m_speed;
        m_rect.moveTo(m_x,m_y);
    }
    if(m_y>=GAME_HEIGHT)
        m_free=true;
}
//攻击判定,这里表示撞击攻击检测。
void EnermyPlane::collisionDetection()
{
    m_power_record++;
    if(m_power_record<=m_power_interval)
    {
        return;
    }
    m_power_record=0;

    if(this->m_free)
    {
        return;
    }

    if(this->m_rect.intersects(Userplane->m_rect))
    {
        Userplane->m_life-=this->m_power;
        qDebug()<<"我方被敌人撞击，这是测试撞击鉴定，当前血量："<<Userplane->m_life;
    }
}
//敌人移动，通过接口移动
void EnermyPlane::updatePosition()
{
    setPosition(0, 0);
}
//敌人
void EnermyPlane::initBullet()
{
    m_life=ENERMY_LIFE;
    m_free=true;
    m_x=-300;
    m_power_record=0;
}




//敌人2初始化
EnermyPlane2::EnermyPlane2():m_launcher()
{
    //图片初始化
    m_plane.load(ENERMY2_PICTURE);

    //坐标初始化
    m_x=(GAME_WIDTH-m_plane.width())/2;
    m_y=GAME_HEIGHT-m_plane.width();

    //初始化边框
    m_rect.setWidth(m_plane.width());
    m_rect.setHeight(m_plane.height());
    m_rect.moveTo(m_x,m_y);

    //初始化生命
    m_life=ENERMY2_LIFE;
    //初始化速度
    m_speed=ENERMY2_SPEED;

    //初始化伤害
    m_power=ENERMY2_POWER;
    //初始化伤害间隔
    m_power_interval=ENERMY2_POWER_INTERVAL;
    //初始化撞击次数
    m_power_record=0;

    //初始化闲置
    m_free=true;
}

void EnermyPlane2::acting()
{
    //每一回合
    //撞击攻击检测
    collisionDetection();
    //已将LauncherEnermySet::collisionLauncherDetection的collisionDetection()重载为执行acting。
    //尝试一次子弹的发射
    m_launcher.shoot(*this);
    //进行一次全体子弹的攻击判定
    m_launcher.collisionLauncherDetection();
    //允许一次全体子弹移动
    m_launcher.updateLauncherPosition();
}

void EnermyPlane2::initBullet()
{
    m_life=ENERMY2_LIFE;
    m_free=true;
    m_x=-300;
    m_power_record=0;
    int i;
    m_launcher.freeLauncher();
}







EnermyPlane3::EnermyPlane3()
{
    //图片初始化
    m_plane.load(ENERMY3_PICTURE);

    //坐标初始化
    m_x=(GAME_WIDTH-m_plane.width())/2;
    m_y=GAME_HEIGHT-m_plane.width();

    //初始化边框
    m_rect.setWidth(m_plane.width());
    m_rect.setHeight(m_plane.height());
    m_rect.moveTo(m_x,m_y);

    //初始化生命
    m_life=ENERMY3_LIFE;
    //初始化速度
    m_speed=ENERMY3_SPEED;

    //初始化伤害
    m_power=ENERMY3_POWER;
    //初始化伤害间隔
    m_power_interval=ENERMY3_POWER_INTERVAL;
    //初始化撞击次数
    m_power_record=0;

    //初始化闲置
    m_free=true;

    m_speed_y=ENERMY3_SPEED_Y;
    //初始化加速器记录
    m_speed_record=0;
    //初始化加速时间间隔
    m_speed_interval=ENERMY3_SPEED_INTERVAL;
    //初始化加速后的速度
    m_strengthened_speed=ENERMY3_STRENGTHENED_SPEED;
    //初始化加速器记录
    m_move_mode=qrand()%3;
    //初始化抛物率
    switch(m_move_mode)
    {
    case 0 : m_parabolic_rate= 0;break;
    case 1 : m_parabolic_rate=ENERMY3_PARABOLIC_RATE;break;
    case 2 : m_parabolic_rate=-ENERMY3_PARABOLIC_RATE;break;
    default: m_parabolic_rate= 0;break;
    }
}

void EnermyPlane3::setPosition(int, int)
{
    if(m_free==true)
    {
        return;
    }

    m_speed_record++;
    if(m_speed_record<=m_speed_interval)
    {
        if(m_y<m_speed_y)
        {
            m_y+=m_speed;
            m_rect.moveTo(m_x,m_y);
        }
    }
    else
    {
        m_y+=m_strengthened_speed;
        if(m_move_mode!=0)
        {
            m_x+=m_parabolic_rate;
            if(m_move_mode==1)
            {
                m_parabolic_rate-=ENERMY3_PARABOLIC_CHANGE_RATE;

            }
            if(m_move_mode==1)
            {
                m_parabolic_rate+=ENERMY3_PARABOLIC_CHANGE_RATE;

            }
            if(m_x>GAME_WIDTH-this->m_plane.width()) m_parabolic_rate-=20;
            if(m_x<0) m_parabolic_rate+=20;
        }
        m_rect.moveTo(m_x,m_y);
    }

    if(m_y>=GAME_HEIGHT)
        this->initBullet();
}

void EnermyPlane3::initBullet()
{
    //初始化生命
    m_life=ENERMY3_LIFE;
    //初始化闲置
    m_free=true;
    //初始化撞击次数
    m_power_record=0;

    //初始化加速器记录
    m_speed_record=0;
    //初始化加速器记录
    m_move_mode=qrand()%3;
    //初始化抛物率
    switch(m_move_mode)
    {
    case 0 : m_parabolic_rate= 0;break;
    case 1 : m_parabolic_rate=ENERMY3_PARABOLIC_RATE;break;
    case 2 : m_parabolic_rate=-ENERMY3_PARABOLIC_RATE;break;
    default: m_parabolic_rate= 0;break;
    }
}
