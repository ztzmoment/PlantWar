#ifndef MPLANT_H
#define MPLANT_H

#include "bomb.h"
#include <QPixmap>
#include "config.h"
#include "MLauncher.h"
#include <QDebug>

class MPlane
{
public:
    //MPlane(){}
    //活动，如发射子弹
    virtual void acting()=0;
    //移动
    virtual void setPosition(int x=0, int y=0)=0;
    //攻击判定,这个可能没用，因为子弹判定也能在acting里进行
    virtual void collisionDetection()=0;
    ~MPlane(){}
public:
    Bomb m_bombs;
    //图片
    QPixmap m_plane;
    //坐标
    int m_x;
    int m_y;
    //判定
    QRect m_rect;
    //生命
    int m_life;
};


/////////////////////////////////////////////////////////////////////////////////////////////////////
//由于这里用到了MPlane的具体内容，没法只是用前向引用声明，并且，下面用到了HeroLancher，所以这里将MLaunch.h里的内容搬到这里来
//好的办法是，把这上面单独做个文件，被include到MLaunch.h里，然后再被这下面的文件include
template<class T, int SIZE, int INTERVAL>
void MLauncher<T,SIZE,INTERVAL>::shoot(MPlane &m_pl)
{
    m_record++;
    if(m_record>=m_interval)
        m_record=0;
    else return;

    int i;
    for (i=0;;i++)
    {
        if(i==SIZE)
        {
            qDebug()<<"英雄子弹数量不足";
            break;
        }
        if(m_bullet[i].m_free)
        {//qDebug()<<"jinxingshoot";
            m_bullet[i].m_free=false;
            m_bullet[i].m_x=m_pl.m_x+m_pl.m_rect.width()/2-m_bullet[i].m_rect.width()/2;
            m_bullet[i].m_y=m_pl.m_y+m_pl.m_rect.height()/2;
            break;
        }
    }
}

typedef MLauncher<HeroBullet,HERO_BULLET_NUM,HERO_SHOOT_INTERVAL> HeroLancher;
//定义enermy子弹
typedef MLauncher<EnermyBullet,ENERMY2_BULLET_NUM,ENERMY2_SHOOT_INTERVAL> EnermyBulletLancher;
//////////////////////////////////////////////////////////////////////////////////////////////




class HeroPlane:public MPlane
{
public:
    HeroPlane();

    virtual void acting();
    virtual void setPosition(int x=0, int y=0);
    //攻击判定,这个可能没用，因为所有子弹判定在launch类里，launch类里的函数也能在acting里进行
    virtual void collisionDetection(){}
public:
    HeroLancher m_launcher;
};



class EnermyPlane:public MPlane
{
public:
    EnermyPlane();
    virtual void acting();
    virtual void setPosition(int x=0, int y=0);
    //攻击判定,这里表示撞击检测。
    virtual void collisionDetection();
    //提供弹夹接口：清空状态
    virtual void initBullet();
    //提供弹夹接口：仅调用setPosition(int x=0, int y=0)
    virtual void updatePosition();
public:
    //敌机速度
    int m_speed;
    //撞击伤害
    int m_power;
    //伤害间隔
    int m_power_interval;
    //撞击伤害间隔记录
    int m_power_record;
    //闲置
    bool m_free;
};




class EnermyPlane2:public EnermyPlane
{
public:
    EnermyPlane2();
    virtual void acting();
    //攻击判定,这里表示撞击检测。继承自EnermyPlane，不重写了
    //virtual void collisionDetection();

    //提供弹夹接口：清空状态继承自EnermyPlane，不重写了。于是子弹在敌机死后不会直接立刻消失
    virtual void initBullet();

    //提供弹夹接口：仅调用setPosition(int x=0, int y=0)。继承自EnermyPlane，不重写了
    //virtual void updatePosition();
public:
    EnermyBulletLancher m_launcher;
};

class EnermyPlane3:public EnermyPlane
{
public:
    EnermyPlane3();
    virtual void setPosition(int x=0, int y=0);
    virtual void initBullet();
public:
    int m_speed_record;
    int m_speed_interval;
    int m_strengthened_speed;//y轴速度
    int m_move_mode;//模式
    int m_parabolic_rate;//
    int m_speed_y;
};

#endif // PLANT_H
