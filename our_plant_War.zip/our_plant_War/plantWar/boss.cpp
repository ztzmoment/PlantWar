#include "boss.h"
#include <QPixmap>
#include "config.h"


Boss::Boss():MPlane()
{
    //boss资源加载
    boss.load(BOSS_PICTURE);

     //敌机矩形
     rect.setWidth(boss.width());
     rect.setHeight(boss.height());

     //敌机位置
     X = GAME_WIDTH/2-rect.width()/2;
     Y = 0-rect.height();

     rect.moveTo(X,Y);

     //碰撞
     m_power_interval=BOSS_POWER_INTERVAL;
     m_power_record=0;
     m_power=BOSS_POWER;

      //敌机状态
      free = true;
      isanger = true;
      isshoot = true;
      isdeath = false;

      //移动速度
      speed = 1;

      //生命值
      health = BOSS_LIFE;

      //射击间隔
      bossshootinterval = BOSS_INTERVAL;
      shootinterval = BOSS_SHOOT_INTERVAL2;
      pauseinterval = BOSS_PAUSE;
      bossshootrecorder = 0;
      shootrecorder = 0;
      movecorder=0;
        m=1;
      pauserecorder = 0;
      shootpoint = (rand() % 10)*100+50;

//        //子弹初始化
//        for (int i=0; i<BOSS_BULLET_NUM; i++)
//        {
//           bullets[i].setBulletPath(BOSS_BULLET_PICTURE);
//            bossbullets[i].initBullet();
//        }
}

void Boss::updatePosition()
{
    //空闲状态，不计算坐标
        if(free)
        {
            return;
        }

        if (Y <= -rect.height()/3)
        {
            Y += 0.5;
        }else{
            movecorder++;
            if(movecorder>BOSS_MOVE){
                movecorder=0;
                X+=rand()%50*m;
                if(X<=0)
                    m=1;
                if(X>GAME_WIDTH-boss.width())
                    m=-1;
            }

        }

        rect.moveTo(X, Y);

}

void Boss::shoot()
{
    if(this->free==1)
        return;
    if (isanger)
        {
            if (isshoot)
            {
                shootrecorder++;
                pauserecorder++;
                if (shootrecorder > shootinterval)
                {
                    shootrecorder = 0;
                    for (int i=0; i<6; i++)
                    {
                        if (i*100+50 == shootpoint) continue;
                        for (int j=0; j<BOSS_BULLET_NUM; j++)
                        {
                            if (bossbullets1[j].m_free)
                            {
                                bossbullets1[j].m_free = false;
                                bossbullets1[j].m_x = qrand()%(GAME_WIDTH-bossbullets1[j].m_bullet.width());
//                                bossbullets1[j].m_y = 0-bossbullets1[j].m_rect.height();
                                bossbullets1[j].updatePosition();

                                break;
                            }
                        }
                    }
                }
                if (pauserecorder > pauseinterval)
                {
                    isshoot = false;
                    pauserecorder = 0;
                    shootpoint = (rand() % 6)*100+50;
                }
            }
            else
            {
                pauserecorder++;
                if (pauserecorder > pauseinterval)
                {
                    pauserecorder = 0;
                    isshoot = true;
                }
            }
            bossshootrecorder++;
            if (bossshootrecorder > bossshootinterval)
            {
                bossshootrecorder = 0;
                for (int i=0; i<BOSS_BULLET_NUM; i++)
                {
                    if (bossbullets2[i].m_free)
                    {

                        bossbullets2[i].m_free = false;
                        bossbullets2[i].m_x = rand() % GAME_WIDTH;
//                        bossbullets2[i].m_y = Y + rect.height()-20;
//                        bossbullets2[i].m_speed = rand() % 2 ? 2 : -2;
                        bossbullets2[i].updatePosition();
                        break;
                    }
                }
            }
        }
        else
        {
            bossshootrecorder++;
            if (bossshootrecorder > bossshootinterval)
            {
                bossshootrecorder = 0;
                for (int i=0; i<BOSS_BULLET_NUM; i++)
                {
                    if (bossbullets2[i].m_free)
                    {

                        bossbullets2[i].m_free = false;
                        bossbullets2[i].m_x = rand() % GAME_WIDTH;
//                        bossbullets2[i].m_y = Y + rect.height()-20;
//                        bossbullets2[i].m_speed = rand() % 2 ? 2 : -2;
                        bossbullets2[i].updatePosition();
                        break;
                    }
                }
            }
    }
}

void Boss::acting()
{
    shoot();
    updatePosition();
    collisionDetection();
}

void Boss::setPosition(int x, int y)
{
}

void Boss::collisionDetection()
{
    m_power_record++;
    if(m_power_record<=m_power_interval)
    {
        return;
    }
    m_power_record=0;

    if(this->free)
    {
        return;
    }

    if(this->rect.intersects(Userplane->m_rect))
    {
        Userplane->m_life-=this->m_power;
        qDebug()<<"我方被敌人撞击，这是测试撞击鉴定，当前血量："<<Userplane->m_life;
    }
}
