#ifndef BOSS_H
#define BOSS_H
#include "MPlant.h"
#include "config.h"
#include "MBullet.h"



class Boss : public MPlane
{
    friend class MainScene;
//    friend class Laser;
public:
    Boss();

    //更新坐标
    void updatePosition();


    void shoot();

    virtual void acting();
    virtual void setPosition(int x=0, int y=0);
    //攻击判定,这个可能没用，因为所有子弹判定在launch类里，launch类里的函数也能在acting里进行
    virtual void collisionDetection();
public:
    //敌机资源对象
    QPixmap boss;

    //位置
    int X;
    int Y;

    //敌机的矩形边框（碰撞检测）
    QRect rect;

    //碰撞以及频率
    int m_power_record;
    int m_power_interval;
    int m_power;

    //状态
    bool free;
    bool isanger;
    bool isshoot;
    bool isdeath;

    //速度
    int speed;

    int movecorder;
    int m;

    //生命值
    int health;

    //射击间隔
    int bossshootinterval;
    int shootinterval;
    int pauseinterval;
    int bossshootrecorder;
    int shootrecorder;
    int pauserecorder;
    int shootpoint;

    //子弹
    BossBullet1 bossbullets1[BOSS_BULLET_NUM];
    BossBullet2 bossbullets2[BOSS_BULLET_NUM];
};

#endif // BOSS_H
