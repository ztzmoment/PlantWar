#include "bullet.h"
#include "config.h"


Bullet::Bullet()
{
    //子弹图片
    m_bullet.load(BULLET_PICTURE);
    //坐标
    m_x=300;
    m_y=300;
    //边界
    m_rect.setWidth(m_bullet.width());
    m_rect.setHeight(m_bullet.height());
    m_rect.moveTo(m_x,m_y);
    //速度
    m_speed=BULLET_SPEED;
    //伤害
    m_power=BULLET_POWER;
    //闲置
    m_free=true;
}

void Bullet::updatePosition()
{
    if(m_free==true)
    {
        return;
    }
    else
    {
        m_y-=m_speed;
        m_rect.moveTo(m_x,m_y);
    }
    if(m_y<=0-50)//减多少没关系，就是让它移出屏幕而已
        m_free=true;
}
