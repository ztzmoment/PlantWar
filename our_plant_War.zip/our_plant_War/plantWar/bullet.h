#ifndef BULLET_H
#define BULLET_H

#include "config.h"
#include <QPixmap>

class Bullet
{
public:
    Bullet();
    //更新子弹坐标
    void updatePosition();

public:
    //图片
    QPixmap m_bullet;
    //坐标
    int m_x;
    int m_y;
    //判定
    QRect m_rect;
    //速度
    int m_speed;
    //伤害
    int m_power;
    //类型
    int sort;
    //闲置
    bool m_free;
};

#endif // BULLET_H
