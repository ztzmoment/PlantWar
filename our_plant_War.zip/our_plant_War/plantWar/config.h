#ifndef CONFIG_H
#define CONFIG_H

//配置开始界面
#define OPEN_WIDTH 467
#define OPEN_HEIGHT 674
#define OPEN_PATH ":/new/prefix1/resourse/ground_main.jpg"



//游戏配置文件
#define GAME_WIDTH 1024                              //窗口宽度
#define GAME_HEIGHT  1200                            //窗口高度
#define GAME_TITLE "飞机大战"                           //标题
#define GAME_RES_PATH "./planeliu.rcc"              //资源位置
#define GAME_TITLE_PICTURE ":/new/prefix1/resourse/hero2.png"    //左上角图片
#define GAME_FRAME_RATE 20                          //刷新率(毫秒)

//map
#define MAP_PICTURE ":/new/prefix1/resourse/20230522212223.jpg"
#define MAP_SPEED 5

//英雄飞机
#define HERO_SORT_SIGN 1                            //英雄飞机标志
#define HERO_PICTURE ":/new/prefix1/resourse/hero.png"
#define HERO_LIFE 100                               //生命
//英雄飞机弹夹
#define HERO_BULLET_NUM 30                         //hero最多子弹数量
#define HERO_SHOOT_INTERVAL 4                       //以刷新率为单位

//英雄子弹1
#define HERO_BULLET_PICTURE ":/new/prefix1/resourse/bullet_5.png"
#define HERO_BULLET_PICTURE2 ":/new/prefix1/resourse/img-plane_1.png"
#define HERO_BULLET_SPEED 40
#define HERO_BULLET_POWER 30

//Boss初始信息
#define BOSS_PICTURE ":/new/prefix1/resourse/Boss2.png"
#define BOSS_MOVE 30
#define BOSS_LIFE 5000
#define BOSS_POWER 10
#define BOSS_INTERVAL 80
#define BOSS_POWER 10
#define BOSS_POWER_INTERVAL 10
#define BOSS_SHOOT_INTERVAL 20
#define BOSS_SHOOT_INTERVAL2 20

//boss子弹信息
#define BOSS_PAUSE 300
#define BOSS_BULLET_POWER 15
#define BOSS_BULLET_SPEED 40
#define BOSS_BULLET_PICTURE ":/new/prefix1/resourse/bullet_2.png"
#define BOSS_BULLET_PICTURE2 ":/new/prefix1/resourse/bullet_1.png"
#define BOSS_BULLET_NUM 50


//敌机总数
#define ENEMY_ALL_NUM 100
#define ENERMY_SORT_SIGN 2   //这个标记了子弹类型，不过没有用过子弹类型

//敌机一的信息
//敌人机群
#define ENERMY_NUM 40
#define ENERMY_INTERVAL 20
//敌人飞机
#define ENERMY_PICTURE ":/new/prefix1/resourse/img-plane_6.png"
#define ENERMY_SPEED 15
#define ENERMY_LIFE 100
#define ENERMY_POWER 5                             //敌人撞击伤害
#define ENERMY_POWER_INTERVAL 5                    //以刷新率为单位,表示敌人撞击造成伤害的时间间隔，

//敌人二的信息
//敌人二机群
#define ENERMY2_NUM 40
#define ENERMY2_INTERVAL 70
//敌人二飞机（基本和飞机一相同）
#define ENERMY2_PICTURE ":/new/prefix1/resourse/img-plane_4.png"
#define ENERMY2_SPEED 10
#define ENERMY2_LIFE 100
#define ENERMY2_POWER 5                             //敌人撞击伤害
#define ENERMY2_POWER_INTERVAL 5                    //以刷新率为单位,表示敌人撞击造成伤害的时间间隔，
//敌人二弹夹
#define ENERMY2_BULLET_NUM 10
#define ENERMY2_SHOOT_INTERVAL 30                   //以刷新率为单位
//敌人子弹
#define ENERMY2_BULLET_PICTURE ":/new/prefix1/resourse/bullet_1.png"
#define ENERMY2_BULLET_SPEED 40
#define ENERMY2_BULLET_POWER 10

//敌机三的信息
//敌人机群
#define ENERMY3_NUM 20
#define ENERMY3_INTERVAL 20
//敌人飞机
#define ENERMY3_PICTURE ":/new/prefix1/resourse/bullet_1.png"
#define ENERMY3_SPEED 30
#define ENERMY3_SPEED_INTERVAL 20                       //敌人出现后多久加速
#define ENERMY3_SPEED_Y 100                             //敌人最多走到哪里
#define ENERMY3_STRENGTHENED_SPEED 40                   //敌人加速后速度
#define ENERMY3_PARABOLIC_RATE 10                       //斜率
#define ENERMY3_PARABOLIC_CHANGE_RATE 1                 //改变率
#define ENERMY3_LIFE 60
#define ENERMY3_POWER 30                                //敌人撞击伤害
#define ENERMY3_POWER_INTERVAL 5


//在mainscence的飞机注册信息
class  EnermyPlane;
class  MPlane;
class  Boss;
extern EnermyPlane *Registerplane[ENEMY_ALL_NUM];
extern MPlane *Userplane;
extern Boss *BOSSPLANE;
extern int gameScore;

//爆炸配置数据
#define BOMB_COMMONENEMY_PATH ":/new/prefix1/resourse/sukoutu-%1.png" //爆炸资源图片
#define BOMB_NUM 20 //爆炸数量
#define BOMB_MAX 7    //爆炸图片最大索引
#define BOMB_INTERVAL 20 //爆炸切图时间间隔

#endif // CONFIG_H
