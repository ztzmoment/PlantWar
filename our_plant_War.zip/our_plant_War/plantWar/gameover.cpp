#include "gameover.h"
#include "ui_gameover.h"
#include "config.h"
#include <QString>
#include "mainscene.h"
#include "mainwindows.h"
gameover::gameover(int a,int b,QWidget *parent) :
    QWidget(parent),
    ui(new Ui::gameover),score(a),diff(b)
{
    ui->setupUi(this);
    QString aa;
    aa="哟西结束,您的分数为："+QString::number(score,10);
    ui->mmlabel->setText(aa);
}

gameover::~gameover()
{
    delete ui;
}


void gameover::on_ReToMain_clicked()
{
    mainwindows *p=new mainwindows;
    p->show();
    this->hide();
}

void gameover::on_pushButton_2_clicked()
{
    MainScene *p=new MainScene(diff,0) ;
    p->show();
    this->hide();
}
