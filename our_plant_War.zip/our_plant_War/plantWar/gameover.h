#ifndef GAMEOVER_H
#define GAMEOVER_H

#include <QWidget>

namespace Ui {
class gameover;
}

class gameover : public QWidget
{
    Q_OBJECT

public:
    explicit gameover(int a,int difficu,QWidget *parent = nullptr);
    ~gameover();

private slots:

    void on_ReToMain_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::gameover *ui;
    int score;
    int diff;
};

#endif // GAMEOVER_H
