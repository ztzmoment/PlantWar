#ifndef HEROPLANE_H
#define HEROPLANE_H
/*
#include <QPixmap>
#include <QRect>
#include "config.h"
#include "MBullet.h"

class HeroPlane
{
public:
    HeroPlane();
    //发射
    void shoot();
    //位置
    virtual void setPosition(int x, int y);

public:
    //图片
    QPixmap m_plane;
    int m_x;
    int m_y;
    //判定
    QRect m_rect;
    //子弹数目
    HeroBullet2 m_bul[HERO_BULLET_NUM];
    //发射间隔
    int m_record;
};


class EnermyPlane: public HeroPlane
{
public:
    EnermyPlane();
    virtual void setPosition(int x, int y);
public:
    bool m_free;
    int m_rate;
    int m_life;
};
*/
#endif // HEROPLANE_H
