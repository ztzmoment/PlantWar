/*
 Navicat MySQL Data Transfer

 Source Server         : Azure
 Source Server Type    : MySQL
 Source Server Version : 50731
 Source Host           : localhost:3306
 Source Schema         : infomation

 Target Server Type    : MySQL
 Target Server Version : 50731
 File Encoding         : 65001

 Date: 23/05/2023 15:06:48
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for player
-- ----------------------------
DROP TABLE IF EXISTS `player`;
CREATE TABLE `player`  (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '用户名',
  `password` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL COMMENT 'player密码',
  `score` int(4) NOT NULL COMMENT '最高分数',
  `Datatime` datetime(0) NOT NULL ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '数据创造时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 125 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of player
-- ----------------------------
INSERT INTO `player` VALUES (1, '朱天泽', '123456', 20, '2023-05-23 15:02:21');
INSERT INTO `player` VALUES (2, '李诗畦', '12121', 1, '2023-05-23 15:03:19');
INSERT INTO `player` VALUES (3, '六并与', '13131', 3, '2023-05-23 15:03:22');
INSERT INTO `player` VALUES (124, '张麻子', '12', 12, '2023-05-23 15:03:35');

SET FOREIGN_KEY_CHECKS = 1;
