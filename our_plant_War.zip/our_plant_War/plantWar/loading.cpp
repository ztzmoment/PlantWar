#include "loading.h"
#include "ui_loading.h"
#include <QProgressBar>
#include <QString>
#include "mainwindows.h"


Loading::Loading(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Loading)
{
    ui->setupUi(this);


    ui->progressBar->setRange(0,100); //设置进度条最小值和最大值(取值范围)

//    m_pConnectProBar->setValue(50);  //设置当前的运行值
    ui->progressBar->reset(); //让进度条重新回到开始
    ui->progressBar->setOrientation(Qt::Horizontal);  //水平方向

    ui->progressBar->setAlignment(Qt::AlignVCenter);  // 对齐方式

    ui->progressBar->setFixedSize(258,20);   //进度条固定大小
    ui->progressBar->setInvertedAppearance(false); //true:反方向  false:正方向
    ui->progressBar->setFormat("Loading...");      //显示加载文本

    ui->progressBar->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);                               //文本对齐方式

    for(int i=0;i<=100;i+=1){
        ui->progressBar->setValue(i);
    }
    this->hide();
//    mainwindows *open=new mainwindows;
//    open->show();
}

Loading::~Loading()
{
    delete ui;
}
