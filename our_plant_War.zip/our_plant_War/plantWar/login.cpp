#include "login.h"
#include "ui_login.h"
#include "mainwindows.h"
#include "regist.h"
#include <QString>
#include <QDebug>
#include "config.h"
#include <QIcon>

login::login(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::login)
{
    setWindowIcon(QIcon(GAME_TITLE_PICTURE));
    ui->setupUi(this);
    ui->edit_name->setPlaceholderText("请输入用户名");
    ui->edit_passward->setPlaceholderText("请输入密码");

    ui->edit_passward->setEchoMode(QLineEdit::Password);
}

login::~login()
{
    delete ui;
}

void login::on_log_button_clicked()
{
    //文件判断登陆是否满足要求

    QString name=ui->edit_name->text();
    qDebug()<<name;
    if(true){
     mainwindows *open=new mainwindows;
     this->hide();
     open->show();
    }

}

void login::on_return_button_clicked()
{
    exit(1);
}

void login::on_reg_button_clicked()
{
    regist* r=new regist;
    this->hide();
    r->show();

}

void login::on_checkBox_clicked(bool checked)
{
    if(checked){
        ui->edit_passward->setEchoMode(QLineEdit::Normal);
    }
    else
        ui->edit_passward->setEchoMode(QLineEdit::Password);
}
