#ifndef LOGIN_H
#define LOGIN_H

#include <QWidget>

namespace Ui {
class login;
}

class login : public QWidget
{
    Q_OBJECT

public:
    explicit login(QWidget *parent = nullptr);
    ~login();

private slots:
    void on_log_button_clicked();

    void on_return_button_clicked();

    void on_reg_button_clicked();

    void on_checkBox_clicked(bool checked);

private:
    Ui::login *ui;
};

#endif // LOGIN_H
