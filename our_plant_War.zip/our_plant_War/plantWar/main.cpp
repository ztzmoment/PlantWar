#include "mainscene.h"
#include <QApplication>
#include <QResource>
#include "config.h"
#include "mainwindows.h"
#include "loading.h"
#include "login.h"
#include <QMessageBox>
#include <QDebug>

#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>
#include <time.h>
int main(int argc, char *argv[])
{
    QApplication a( argc,argv);


//    qDebug()<<"available drivers:";
//        QStringList drivers = QSqlDatabase::drivers();
//        foreach(QString driver, drivers)
//            qDebug()<<driver;

    QSqlDatabase db = QSqlDatabase::addDatabase("QODBC");
        db.setHostName("127.0.0.1");
        db.setPort(3306);
        db.setDatabaseName("d1");
        db.setUserName("root");
        db.setPassword("ztz20041112");
        bool ok = db.open();
        if (ok){
            qDebug()<<"连接成功";
            //QMessageBox::information(this, "infor", "success");
        }
        else {
            //QMessageBox::information(this, "infor", "open failed");
            qDebug()<<"error open database because"<<db.lastError().text();
        }
        QSqlQuery query;
        bool success=query.exec("SELECT name, salary FROM employee WHERE salary > 50000");


            if(success)
                qDebug()<<QObject::tr("数据库表创建成功！\n");
            else
                qDebug()<<QObject::tr("数据库表创建失败！\n");

        while(query.next())
        {
            qDebug() << query.value(0).toInt() << query.value(1).toString();
        }


//    QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL");
//        db.setHostName("127.0.0.1");  //连接本地主机
//        db.setPort(3306);
//        db.setDatabaseName("数据库名");
//        db.setUserName("用户名");
//        db.setPassword("密码");
//        bool ok = db.open();
//        if (ok){
//            QMessageBox::information(this, "infor", "link success");
//        }
//        else {
//            QMessageBox::information(this, "infor", "link failed");
//            qDebug()<<"error open database because"<<db.lastError().text();
//        }


    //注册二进制资源
    QResource::registerResource(GAME_RES_PATH);

//    Loading a1;
//    a1.show();
    login lg;
    lg.show();

//    MainScene w;
//    w.show();

    return a.exec();
}
