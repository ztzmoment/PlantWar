#include "mainscene.h"
#include "config.h"
#include <QIcon>
#include <QTimer>
#include <QPainter>
#include <QMouseEvent>
#include <QtGlobal>
#include <QDebug>
#include "MBullet.h"
#include "MLauncher.h"
#include "MPlant.h"
#include "boss.h"
#include "gameover.h"
#include "bomb.h"

EnermyPlane *Registerplane[ENEMY_ALL_NUM]={NULL};
MPlane *Userplane=NULL;
static int boss_interval=0;
Boss *BOSSPLANE=NULL;
static int gameplaying=0;
int gameScore=0;

//Boss boss;
//构造函数
MainScene::MainScene(int difficulty,int modol,QWidget *parent) :
    QWidget(parent),difficulty(difficulty),modol(modol)
{

    //初始化
    initScene();
    setWindowIcon(QIcon(GAME_TITLE_PICTURE));
    //开始运行
    play_game();
    //设置鼠标默认跟踪
    setMouseTracking(true);

}
//析构函数
MainScene::~MainScene()
{
}


//初始化（使用于构造函数）
void MainScene::initScene()
{
    //设置窗口固定
    setFixedSize(GAME_WIDTH,GAME_HEIGHT);
    //设置标题
    setWindowTitle(GAME_TITLE);
   //设置图标:\前缀\相对路径
    setWindowIcon(QIcon(GAME_TITLE_PICTURE));
    //定时器
    m_time.setInterval(GAME_FRAME_RATE);
}


//开始游戏
void MainScene::play_game()
{
    //启动定时器
    m_time.start();

    //注册所有飞机到全局变量///////////////////////////注意此处,容易出bug
    Userplane=&m_plane;
    int i,j;//i是m_enermyN_launcher容器的索引，j是Registerplane的索引
    for(i=0,j=0;i<ENERMY_NUM;i++,j++)
    {

        if(j>=ENEMY_ALL_NUM)
            qDebug()<<"敌机总数注册超过ENEMY_ALL_NUM，无法注册";
        Registerplane[j]=&(m_enermy_launcher.m_bullet[i]);
        qDebug()<<"正在注册敌机";
    }
    for(i=0;i<ENERMY2_NUM;i++,j++)
    {

        if(j>=ENEMY_ALL_NUM)
            qDebug()<<"敌机总数注册超过ENEMY_ALL_NUM，无法注册";
        Registerplane[j]=&(m_enermy2_launcher.m_bullet[i]);
        qDebug()<<"正在注册敌机2";
    }
    for(i=0;i<ENERMY3_NUM;i++,j++)
    {

        if(j>=ENEMY_ALL_NUM)
            qDebug()<<"敌机总数注册超过ENEMY_ALL_NUM，无法注册";
        Registerplane[j]=&(m_enermy3_launcher.m_bullet[i]);
        qDebug()<<"正在注册敌机3";
    }
    BOSSPLANE=&boss;
    ///////////////////////////////////////////////////////

    //监听信号
    connect(&m_time,&QTimer::timeout,
        [=](){
        qDebug()<<"6";
            //更新元素坐标
            updatePosition();
            //绘制形象
            update();
        }
    );
}
//更新位置
void MainScene::updatePosition()
{
    //更新地图坐标
    m_map.mapPosition();

    //本飞机动作
    m_plane.acting();
    if(boss.free==1)
    {
        int di=difficulty+1;
        for(int i=0;i<di;i++)
        {
            //敌机发射
            m_enermy_launcher.shoot();
            //敌机3发射
            m_enermy3_launcher.shoot();

            //敌机2发射
            m_enermy2_launcher.shoot();
        }


    }
    //敌机移动
    m_enermy_launcher.updateLauncherPosition();
    //敌机动作（acting）
    m_enermy_launcher.collisionLauncherDetection();

    //敌机2移动
    m_enermy2_launcher.updateLauncherPosition();
    //敌机2动作（acting）
    m_enermy2_launcher.collisionLauncherDetection();

    //敌机3移动
    m_enermy3_launcher.updateLauncherPosition();
    //敌机3动作（acting）
    m_enermy3_launcher.collisionLauncherDetection();

    //bomb m_bombs[7];
    //for(int i = 0; i < BOMB_NUM; i++)
    //{
    //    if(m_bombs[i].m_free == false)
    //    {
    //        m_bombs[i].updateinfo();
    //    }
    //}

    boss_interval++;
    if(boss_interval>BOSS_INTERVAL&&boss_interval<10000)
    {
        boss.free=0;
        boss_interval=100001;
    }
    if(boss.free==0)
       { boss.acting();}


    static int itervv=0;
    itervv++;
    if(itervv%20==1)
    {
        gameScore++;
    }
}

void MainScene::enermyToScene()
{

}

//跟随鼠标,系统调用，不需要自己使用
void MainScene::mouseMoveEvent(QMouseEvent *event)
{

    int x=event->x();
    int y=event->y();
    int height=m_plane.m_plane.height(),width=m_plane.m_plane.width();
    x=x-width/2;
    y=y-height/2;
    if(x<=0) x=0;
    if(x>=GAME_WIDTH-width) x=GAME_WIDTH-width;
    if(y<=0) y=0;
    if(y>=GAME_HEIGHT-height) y=GAME_HEIGHT-height;
    m_plane.setPosition(x,y);

}
//绘制图案
void MainScene::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    //绘制地图
    painter.drawPixmap(0,m_map.m_map1_posY,m_map.m_map1);
    painter.drawPixmap(0,m_map.m_map2_posY,m_map.m_map2);
    painter.drawPixmap(m_plane.m_x,m_plane.m_y,m_plane.m_plane);
    int i;


    for (i=0;i<HERO_BULLET_NUM;i++)
    {
        if(m_plane.m_launcher.m_bullet[i].m_free==false)
        {
            painter.drawPixmap(m_plane.m_launcher.m_bullet[i].m_x,m_plane.m_launcher.m_bullet[i].m_y,m_plane.m_launcher.m_bullet[i].m_bullet);
        }
    }


    //绘制enermy
    for (i=0;i<ENERMY_NUM;i++)
    {
        if(m_enermy_launcher.m_bullet[i].m_free==false)
        {
            painter.drawPixmap(m_enermy_launcher.m_bullet[i].m_x,m_enermy_launcher.m_bullet[i].m_y,m_enermy_launcher.m_bullet[i].m_plane);
        }
    }
    //绘制enermy2和子弹________________________________________________这里会造成bug，因为死去的敌机不画，其子弹也不画，但子弹存在，于是子弹会隐身。解决方案：在敌人死后，用敌人init将子弹消除
    for(i=0;i<ENERMY2_NUM;i++)
    {
        if(m_enermy2_launcher.m_bullet[i].m_free==false)
        {
            painter.drawPixmap(m_enermy2_launcher.m_bullet[i].m_x,m_enermy2_launcher.m_bullet[i].m_y,m_enermy2_launcher.m_bullet[i].m_plane);
            for(int j=0;j<ENERMY2_BULLET_NUM;j++)
            {
                if(m_enermy2_launcher.m_bullet[i].m_launcher.m_bullet[j].m_free==false)
                {
                    painter.drawPixmap(m_enermy2_launcher.m_bullet[i].m_launcher.m_bullet[j].m_x, m_enermy2_launcher.m_bullet[i].m_launcher.m_bullet[j].m_y, m_enermy2_launcher.m_bullet[i].m_launcher.m_bullet[j].m_bullet);
                }
            }
        }


    }
    //绘制enermy3
    for (i=0;i<ENERMY3_NUM;i++)
    {
        if(m_enermy3_launcher.m_bullet[i].m_free==false)
        {
            painter.drawPixmap(m_enermy3_launcher.m_bullet[i].m_x,m_enermy3_launcher.m_bullet[i].m_y,m_enermy3_launcher.m_bullet[i].m_plane);
        }
    }

    if(boss.free==0)
    {

            painter.drawPixmap(boss.X,boss.Y,boss.boss);
            for (int i=0; i<BOSS_BULLET_NUM; i++)
            {
                if (boss.bossbullets1[i].m_free == false)
                {
                    boss.bossbullets1[i].updatePosition();
                    painter.drawPixmap(boss.bossbullets1[i].m_x,boss.bossbullets1[i].m_y,boss.bossbullets1[i].m_bullet);
                }
            }
            for (int i=0; i<BOSS_BULLET_NUM; i++)
            {
                if (boss.bossbullets2[i].m_free == false)
                {
                    boss.bossbullets2[i].updatePosition();
                    painter.drawPixmap(boss.bossbullets2[i].m_x,boss.bossbullets2[i].m_y,boss.bossbullets2[i].m_bullet);
                }
            }

    }

    for(int i = 0; i < ENEMY_ALL_NUM; i++)
    {
        if(Registerplane[i] !=NULL)
        {
            if(Registerplane[i]->m_bombs.bombfree == false)
            {
                painter.drawPixmap(Registerplane[i]->m_bombs.m_x,Registerplane[i]->m_bombs.m_y, Registerplane[i]->m_bombs.pixArr[Registerplane[i]->m_bombs.index]);
                Registerplane[i]->m_bombs.updateInfo();
            }
        }
    }

    painter.setPen(QPen(Qt::red));
    QFont font("Arial", 18, QFont::Bold);
    painter.setFont(font);

    QString life_actual=QString::number(m_plane.m_life,10);
    QString life_see = "plane life:"+life_actual;
    int textWidth = painter.fontMetrics().width(life_see);
    int textHeight = painter.fontMetrics().height();

    QString score_see = "score:"+QString::number(gameScore,10);
    int text2Height = painter.fontMetrics().height();

    painter.drawText(GAME_WIDTH-textWidth, textHeight, life_see);
    painter.drawText(0, text2Height, score_see);

    if(m_plane.m_life<0)
        gameplaying=1;
    if(gameplaying==1)
    {
        // 计算文字的宽度和高度
        QString text = "GAME OVER!";
        int textWidth = painter.fontMetrics().width(text);
        int textHeight = painter.fontMetrics().height();

        // 将文字绘制到中心位置
        painter.drawText(GAME_WIDTH/2 - textWidth / 2, GAME_HEIGHT/2 + textHeight / 3, text);

        gameover *game1=new gameover(gameScore,difficulty) ;
        game1->show();

        gameScore=0;
        gameplaying=0;
        boss_interval=0;
        this->hide();
        this->m_time.stop();
    }
    if(boss.free==0)
    {
        QString boss_see = "bosslife:"+QString::number(boss.health,10);
        painter.drawText(100,100, boss_see);
    }
}
//子弹和敌机的碰撞检测
/*
void MainScene::collisionDetection()
{
    int i,j;
    for(i=0;i<ENERMY_NUM;i++)
    {
        if(ene_plane[i].m_free)
        {
            continue;
        }
        for(j=0;j<HERO_BULLET_NUM;j++)
        {
            if(m_plane.m_bul[j].m_free)
                continue;

            if(ene_plane[i].m_rect.intersects(m_plane.m_bul[j].m_rect))
            {
                m_plane.m_bul[j].m_free=true;
                ene_plane[i].m_life-=m_plane.m_bul[j].m_power;
                if(ene_plane[i].m_life<=0)
                {
                    ene_plane[i].m_free=true;
                }
            }
        }
    }

}
*/
