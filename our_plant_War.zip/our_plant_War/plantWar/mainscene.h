#ifndef MAINSCENE_H
#define MAINSCENE_H

#include <QWidget>
#include <QTimer>
#include "map.h"
#include "heroplane.h"
#include "MBullet.h"
#include "MPlant.h"
#include "MEnermyLauncher.h"
#include "boss.h"
#include "bomb.h"

class MainScene : public QWidget
{
    Q_OBJECT

public:
    explicit MainScene(int difficulty,int modol,QWidget *parent = nullptr);
    ~MainScene();


    //开始游戏




    //初始化场景
    void initScene();
    //开始游戏
    void play_game();
    //加载界面
    void loading_game();
    //更新全部坐标
    void updatePosition();
    //敌机出场
    void enermyToScene();
    //鼠标移动,此函数来自qt，不可自定名称
    void mouseMoveEvent(QMouseEvent * Event);
    //绘制屏幕 此函数来自qt，不可自定名称
    void paintEvent(QPaintEvent *);
    //碰撞检测
    void collisionDetection();


public:

    int difficulty;
    int modol;

    //地图对象
    map m_map;
    //飞机对象
    HeroPlane m_plane;
    //定时器
    QTimer m_time;
    //敌机发射器
    LauncherEnermySet m_enermy_launcher;
    //敌机2发射器
    LauncherEnermy2Set m_enermy2_launcher;
    //敌机3发射器
    LauncherEnermy3Set m_enermy3_launcher;
    //boss
    Boss boss;
    //爆炸


};



#endif // MAINSCENE_H
