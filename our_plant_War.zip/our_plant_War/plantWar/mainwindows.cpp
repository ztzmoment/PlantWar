#include "mainwindows.h"
#include "ui_mainwindows.h"

#include <QWidget>
#include "config.h"
#include <QPainter>
#include <QMouseEvent>
#include <QDebug>
#include "mainscene.h"
#include <QComboBox>
#include "login.h"
#include "QMainWindow"

mainwindows::mainwindows(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::mainwindows)
{
    setWindowIcon(QIcon(GAME_TITLE_PICTURE));
    ui->setupUi(this);
    ui->widget->setFixedSize(800,500);

}

mainwindows::~mainwindows()
{
    delete ui;
}

void mainwindows::on_pushButton_clicked()
{
    //设置难度
    int difficulty = -1;
    if(ui->difficulty_box->currentText() == "easy")
    {
        difficulty = 0;
    }
    else if(ui->difficulty_box->currentText() == "normal")
    {
        difficulty = 1;
    }
    else if(ui->difficulty_box->currentText() == "hard")
    {
        difficulty = 2;
    }

    int model = -1;
    if(ui->model_box->currentText() == "普通模式")
    {
        model = 0;
    }
    else if(ui->model_box->currentText() == "无尽模式")
    {
        model = 1;
    }


    //设置模式
    MainScene* win_mainscene = new MainScene(difficulty, model);
    win_mainscene->setWindowModality(Qt::ApplicationModal);
    this->hide();
    win_mainscene->show();

//    MainScene* w=new MainScene;
//    w->show();
//    this->hide();
}

void mainwindows::on_return_button_clicked()
{
    this->close();
    login* lg=new login;
    lg->show();
}

void mainwindows::on_return_2_clicked()
{
    this->close();
    login* lg=new login;
    lg->show();
}
