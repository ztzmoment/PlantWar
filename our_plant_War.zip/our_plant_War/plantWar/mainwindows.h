#ifndef MAINWINDOWS_H
#define MAINWINDOWS_H

#include <QMainWindow>
#include<QSqlDatabase>



namespace Ui {
class mainwindows;
}

class mainwindows : public QMainWindow
{
    Q_OBJECT

public:
    explicit mainwindows(QWidget *parent = nullptr);
    ~mainwindows();

private slots:
    void on_pushButton_clicked();

    void on_return_button_clicked();

    void on_return_2_clicked();

private:
    Ui::mainwindows *ui;
};

#endif // MAINWINDOWS_H
