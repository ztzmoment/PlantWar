#include "map.h"
#include "config.h"


map::map()
{
    //初始化地图
    m_map1.load(MAP_PICTURE);
    m_map2.load(MAP_PICTURE);
    //初始化位置
    m_map1_posY = -GAME_HEIGHT;
    m_map2_posY = 0;
    //初始化速度
    m_scroll_speed = MAP_SPEED;
}

void map::mapPosition()
{
    if(m_map1_posY>=0)
    {
        m_map1_posY=-GAME_HEIGHT;
        m_map2_posY=0;
    }
    m_map1_posY+=m_scroll_speed;
    m_map2_posY+=m_scroll_speed;

}
