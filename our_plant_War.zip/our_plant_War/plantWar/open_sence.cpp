#include "open_sence.h"
#include "ui_open_sence.h"
#include <QWidget>
#include "config.h"
#include <QPainter>
#include <QMouseEvent>
#include <QDebug>
#include "mainscene.h"

open_sence::open_sence(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::open_sence)
{
    ui->setupUi(this);
    setWindowTitle(GAME_TITLE);
    setFixedSize(OPEN_WIDTH,OPEN_HEIGHT);
    if(!sence.load(OPEN_PATH)){
        qDebug()<<"没打开";
    }
    QPainter painter;
    painter.drawPixmap(0,0,sence);

}

open_sence::~open_sence()
{
    delete ui;
}

void open_sence::on_start_clicked()
{
//    MainScene* w=new MainScene;
//    w->show();
//    this->hide();
}
