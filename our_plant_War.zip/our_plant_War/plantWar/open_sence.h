#ifndef OPEN_SENCE_H
#define OPEN_SENCE_H

#include <QWidget>
#include <QPixmap>

namespace Ui {
class open_sence;
}

class open_sence : public QWidget
{
    Q_OBJECT

public:
    explicit open_sence(QWidget *parent = nullptr);
    ~open_sence();

private slots:
    void on_start_clicked();

public:
    QPixmap sence;

private:
    Ui::open_sence *ui;
};

#endif // OPEN_SENCE_H
