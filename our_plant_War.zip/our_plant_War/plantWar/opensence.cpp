#include "opensence.h"
#include "config.h"
#include <QDebug>
#include <QtGlobal>
#include <QPixmap>
#include "mainscene.h"
opensence::opensence()
{
    if(!sence.load(OPEN_PATH)){
        qDebug()<<"dakaishibai";
    }
    else
        qDebug()<<"dakaichenggong";
}

void opensence::initsence()
{
    if(!sence.load(OPEN_PATH)){
        qDebug()<<"dakaishibai";
    }
    else
        qDebug()<<"dakaichenggong";

}

