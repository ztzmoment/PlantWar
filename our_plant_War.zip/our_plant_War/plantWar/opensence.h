#ifndef OPENSENCE_H
#define OPENSENCE_H
#include <QPixmap>

class opensence
{
public:
    opensence();
    void initsence();

public:
    QPixmap sence;
};

#endif // OPENSENCE_H
