#ifndef PLAYER_H
#define PLAYER_H
#include <QString>

class player
{
public:
    player();
public:
    QString name;
    QString passward;
    float score;
};

#endif // PLAYER_H
