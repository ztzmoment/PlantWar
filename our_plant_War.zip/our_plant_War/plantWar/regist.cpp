#include "regist.h"
#include "ui_regist.h"

#include "QMessageBox"
#include "login.h"

regist::regist(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::regist)
{
    ui->setupUi(this);
    ui->edit_name->setPlaceholderText("为你的战机起一个响亮的名字");
    ui->edit_passward->setPlaceholderText("请输入密码");
    ui->com_edit_passward->setPlaceholderText("请再次确认密码");
    ui->edit_passward->setEchoMode(QLineEdit::Password);
    ui->com_edit_passward->setEchoMode(QLineEdit::Password);
}

regist::~regist()
{
    delete ui;

}


void regist::on_checkBox_clicked(bool checked)
{
    if(checked){
        //明文
        ui->edit_passward->setEchoMode(QLineEdit::Normal);
    }else{
        ui->edit_passward->setEchoMode(QLineEdit::Password);
    }
}

void regist::on_checkBox_2_clicked(bool checked)
{
    if(checked){
        //明文
        ui->com_edit_passward->setEchoMode(QLineEdit::Normal);
    }else{
        ui->com_edit_passward->setEchoMode(QLineEdit::Password);
    }
}

void regist::on_pushButton_clicked()
{
    if(ui->edit_passward->text().trimmed()!=ui->com_edit_passward->text().trimmed()){    //检测确认密码
        QMessageBox::warning(this, tr("警告！"),tr("两次密码不一致！"),QMessageBox::Yes);
        return;
    }else
    {
        QMessageBox::warning(this, tr("欢迎！"),tr("注册成功！"),QMessageBox::Yes);
        this->close();
        login* lg =new login;
        lg->show();

    }
}

void regist::on_pushButton_2_clicked()
{
    this->close();
    login* lg =new login;
    lg->show();

}
